<?php

return [

	'view' => 'site.breadcrumbs',

];
