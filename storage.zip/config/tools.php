<?php

return [
    'logo_url' => '/assets/images/logo.png',
    'footer_logo_url' => '/assets/images/logof.png',
];
