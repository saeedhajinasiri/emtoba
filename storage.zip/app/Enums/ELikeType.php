<?php

namespace App\Enums;

class ELikeType extends BaseEnum
{
    const thumbs_up = 1;
    const thumbs_down = 2;
}
