<?php

namespace App\Enums;

class EWeekDays extends BaseEnum
{
    const saturday = 1;
    const sunday = 2;
    const monday = 3;
    const tuesday = 4;
    const wednesday = 5;
    const thursday = 6;
    const friday = 7;
}
