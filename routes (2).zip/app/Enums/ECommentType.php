<?php

namespace App\Enums;

class ECommentType extends BaseEnum
{
    const pending = 1;
    const approved = 2;
    const rejected = 3;
}
