<?php

namespace App\Enums;

class ETradeType extends BaseEnum
{
    const local_sell = 1;
    const local_buy = 2;
}
