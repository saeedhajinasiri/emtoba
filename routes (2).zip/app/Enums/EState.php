<?php

namespace App\Enums;

class EState extends BaseEnum
{
    const enabled = 1;
    const disabled = 0;
}
