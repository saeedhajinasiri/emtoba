<?php

namespace App\Forms\Admin;

use App\Restaurant;
use App\Category;
use App\Tag;

class TranslationForm extends AdminForm
{
    public function buildForm()
    {
        parent::buildForm();
    }
}
