<?php

return [
    'home.my_story' => 'داستان من',
    'home.download_resume' => 'دانلود رزومه',
    'home.personal_information' => 'اطلاعات شخصی',
    'home.year' => 'سال',
    'home.name' => 'نام',
    'home.age' => 'سن',
    'home.telephone' => 'تلفن',
    'home.email' => 'ایمیل',
    'home.address' => 'آدرس',
    'home.skills' => 'مهارت‌ها',
    'home.experience' => 'تجربیات',
    'home.educations' => 'تحصیلات',
    'blog.index' => 'بلاگ',
    'comment.title' => 'کامنت',
    'comments.title' => 'کامنت ها',
    'hits.title' => 'بازدید',
    'likes.thankYou' => 'مرسی',
    'blogs.you_took_your_vote_back' => 'لایکت با موفقیت بازگردانده شد',
    'blogs.comment_liked' => 'لایکت با موفقیت ثبت شد',
];
