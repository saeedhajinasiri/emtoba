<footer class="main-footer">
    <div class="pull-right hidden-xs"> <b>Version</b> 1.0</div>
    <strong>Copyright &copy; 2016-{{ date('Y') }} .</strong> All rights reserved. <i class="fa fa-heart color-green"></i>
</footer>