<aside class="main-sidebar">
    <!-- sidebar -->
    <div class="sidebar">

        <!-- Sidebar user panel -->
        <div class="user-panel text-center">
            <div class="image">
                <img src="{{ $user->avatar_link }}" class="img-circle" alt="User Image">
            </div>
            <div class="info">
                <p>{{ $user->name }}</p>
                <a href="{{ route('admin.profile.index') }}"><i class="pe-7s-key"></i> @lang('admin.logout') </a>
            </div>
        </div>

        <!-- search form -->
        {{--<form action="#" method="get" class="sidebar-form">
            <div class="input-group">
                <input type="text" name="q" class="form-control" placeholder="Search...">
                <span class="input-group-btn">
                    <button type="submit" name="search" id="search-btn" class="btn"><i class="fa fa-search"></i></button>
                </span>
            </div>
        </form>--}}

        <ul class="sidebar-menu">
            <li class="header">منوی اصلی</li>
            {{--<li>
                <a href="{{ route('admin.dashboard.index') }}"><i class="ti-home"></i> <span> {{ trans('admin.aside.dashboard') }}</span> </a>
            </li>--}}
            {!! $menu !!}
            {{--<li class="treeview">
                <a href="#">
                    <i class="ti-pencil-alt"></i><span> {{ trans('admin.content.menuTitle') }}</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="{{ route('admin.restaurants.index') }}"> <i class="ti-pencil-alt"></i> {{ trans('admin.restaurants.index') }}</a></li>
                    <li><a href="{{ route('admin.categories.index') }}"> {{ trans('admin.categories.index') }}</a></li>
                </ul>
            </li>
            <li class="treeview">
                <a href="#">
                    <i class="ti-user"></i><span> {{ trans('admin.users.menuTitle') }}</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="{{ route('admin.users.index') }}"> {{ trans('admin.users.index') }}</a></li>
                    <li><a href="{{ route('admin.roles.index') }}"> {{ trans('admin.roles.index') }}</a></li>
                    <li><a href="{{ route('admin.permissions.index') }}"> {{ trans('admin.permissions.index') }}</a></li>
                </ul>
            </li>

            <li class="header">لیبل‌ها</li>
            <li><a href="#"><i class="fa fa-circle color-green"></i> <span>Important</span></a></li>
            <li><a href="#"><i class="fa fa-circle color-red"></i> <span>Warning</span></a></li>
            <li><a href="#"><i class="fa fa-circle color-yellow"></i> <span>Information</span></a></li>--}}
        </ul>
    </div> <!-- /.sidebar -->
</aside>