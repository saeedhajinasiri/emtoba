<header class="main-header">
    <a href="{{ URL::to('/') }}" class="header-logo ajax">
        <img src="{{ URL::to('/') }}/assets/images/logo.png" alt="">
    </a>

    <div class="nav-button-wrap">
        <div class="nav-button">
            <span class="nos"></span>
            <span class="ncs"></span>
            <span class="nbs"></span>
            <div class="menu-button-text">Menu</div>
        </div>
    </div>

    <div class="header-contacts">
        <ul>
            <li><span> Call: </span> <a href="tel:{{ $settings['mobile'] }}">{{ $settings['mobile'] }}</a></li>
            <li><span> Email: </span> <a href="mailto:{{ $settings['email'] }}">{{ $settings['email'] }}</a></li>
        </ul>
    </div>
</header>

{{--
<section id="topbar" class="construct header-top">
    <div class="container-fluid">
        <div class="row">
            <div class="contact-info pull-right">
                <ul>
                    @if(\Auth::check())
                        <li><a href="{{ \Auth::user()->panel_link }}"><i class="fa fa-user"></i>{{ \Auth::user()->full_name }}</a></li>
                        <li><a href="{{ url('logout') }}"><i class="fa fa-exit"></i>خروج</a></li>
                    @else
                        <li><a href="{{ url('/register') }}"><i class="fa fa-user"></i>ثبت نام کنید </a> | <a href="{{ url('/login') }}">وارد شوید</a></li>
                    @endif
                    @if($settings['address'])
                        <li><i class="fa fa-map-marker"></i>{{ $settings['address'] }}</li>
                    @endif
                    @if($settings['email'])
                        <li><a href="mailto:{{ $settings['email'] }}"><i class="fa fa-envelope"></i>{{ $settings['email'] }}</a></li>
                    @endif
                    @if($settings['tel'])
                        <li><a href="tel:{{ $settings['tel'] }}"><i class="fa fa-phone"></i>{{ $settings['tel'] }}</a></li>
                    @endif
                </ul>
            </div>
            <div class="social pull-left">
                <ul>
                    @if($settings['instagram_url'])
                        <li>
                            <a target="_blank" href="{{ $settings['instagram_url'] }}">
                                <img src="/assets/images/icons/instag.png" alt="کانال اینستاگرام ابزار آلات کوچک تولز"/>
                            </a>
                        </li>
                    @endif
                    @if($settings['facebook_url'])
                        <li>
                            <a target="_blank" href="{{ $settings['facebook_url'] }}">
                                <img src="/assets/images/icons/fb.png" alt="کانال فیسبوک ابزار آلات کوچک تولز"/>
                            </a>
                        </li>
                    @endif
                    @if($settings['telegram_url'])
                        <li>
                            <a target="_blank" href="{{ $settings['telegram_url'] }}">
                                <img src="/assets/images/icons/telegram.png" alt="کانال تلگرام ابزار آلات کوچک تولز"/>
                            </a>
                        </li>
                    @endif
                </ul>
            </div>
        </div>
    </div>
</section>
<header class="construct header-curvy">
    <div class="container-fluid">
        <div class="clearfix">
            <div class="pull-right logo">
                <a href="{{ url('/') }}">
                    <img src="/assets/images/logo.png" alt="koochak tools - لوگوی ابزار آلات کوچک">
                </a>
            </div>
            <div class="search-box">
                <div class="container-fluid">
                    <div class="pull-left search col-lg-3 col-md-4 col-sm-5 col-xs-12">
                        <form class="row" action="#">
                            <input type="text" placeholder="جستجو ...">
                            <button type="submit"><i class="glyphicon glyphicon-search"></i></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="cart-box">
        <div class="container-fluid">
            <div class="pull-left cart col-lg-6 col-xs-12">
                @if(isset($basketCarts['projects']) && count($basketCarts['projects']) > 0)
                    <p>
                        <i class="glyphicon-shopping-cart glyphicon"></i> شما<span>{{ count($basketCarts['projects']) }}</span> آیتم در سبدتان دارید. قیمت کل
                        <span>{{ number_format($basketCarts['total_price']) }} @lang('site.toman')</span>
                    </p>
                @else
                    <p><i class="glyphicon-shopping-cart glyphicon"></i> سبد خرید شما خالی است.</p>
                @endif
            </div>
        </div>
    </div>

    <div class="container-fluid">
        <div class="clearfix">
            <nav class="pull-right mainmenu-container clearfix">
                <button class="mainmenu-toggler navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
                    <i class="glyphicon-align-justify glyphicon"></i>
                </button>
                <ul class="mainmenu pull-right">
                    <li>
                        <a href="{{ route('site.index') }}">خانه</a>
                    </li>
                    @foreach($categories as $category)
                        <li>
                            <a href="{{ route('site.projects.categories', $category['slug']) }}">{{ $category['title'] }}</a>
                            @if(isset($category['children']) && count($category['children']) > 0)
                                <ul class="submenu">
                                    @foreach($category['children'] as $child)
                                        <li><a href="{{ route('site.projects.categories', $child['slug']) }}">{{ $child['title'] }}</a></li>
                                    @endforeach
                                </ul>
                            @endif
                        </li>
                    @endforeach
                </ul>
            </nav>
        </div>
    </div>
</header>--}}
