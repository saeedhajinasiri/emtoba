<!DOCTYPE html>
<html lang="en">
<head>
    @yield('meta_tags')
    <link id="favicon" rel="icon" type="image/png" href="{{ URL::to('/') }}/assets/images/favicon.ico">
    <!--[if lt IE 9]>
    <script>
        var OLD_IE = true;
    </script>
    <![endif]-->
    <link href="{{ URL::to('/') }}/assets/css/main.css" rel="stylesheet">
    @yield('stylesheets')
</head>
<body>
<div class="page-wrapper">
    {{--<div class="preloader"></div>--}}
    @include('site.header')
    @include('flash::message')
    {{--@if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif--}}

    @yield('content')

    @include('site.footer')
</div>
<div class="scroll-to-top"><span class="fa fa-arrow-up"></span></div>

<script src="{{ url::to('/') }}/assets/js/jquery.js"></script>
<script src="{{ url::to('/') }}/assets/js/bootstrap.min.js"></script>
@yield('scripts')
</body>
</html>