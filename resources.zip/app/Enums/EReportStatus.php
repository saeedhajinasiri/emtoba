<?php

namespace App\Enums;

class EReportStatus extends BaseEnum
{
    const pending = 1;
    const checked = 2;
    const closed = 3;
}
