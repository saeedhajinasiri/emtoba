<?php

namespace App\Enums;

class ELinkType extends BaseEnum
{
    const about = 1;
    const support = 2;
    const service = 3;
}
