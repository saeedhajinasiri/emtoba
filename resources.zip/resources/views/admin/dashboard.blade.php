@extends('admin.master')

@section('content')
    <div class="row">
        <!-- Line Chart -->
    </div>
@stop
