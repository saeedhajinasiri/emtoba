<section class="parallax-section theme-overlay overlay-deep-black pt-200 pb-200" style="background-image:url('/images/parallax/image-3.jpg');">
    <div class="container">
        <div class="row clearfix">
            <div class="col-md-8 col-md-offset-2 text-center pt-50 pb-50">
                <h1 class="fs-72 mb-0 color-theme">404</h1>
                <h2 class="color-theme mb-10">صفحه مورد نظر یافت نشد!</h2>
                <a href="/" class="btn-thm btn-xs mt-20">بازگشت به صفحه اصلی <i class="fa fa-arrow-circle-left"></i></a>
            </div>
        </div>
    </div>
</section>
